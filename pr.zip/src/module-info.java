module pr {
	requires java.desktop;
	requires java.datatransfer;
	requires jdk.compiler;
}