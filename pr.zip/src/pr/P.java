package pr;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class P extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea1;
	String address, runAddress;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P frame = new P();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public P() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		//�뙣�꼸
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		contentPane.add(splitPane, BorderLayout.CENTER);
		
		JTextArea textArea1 = new JTextArea();
		splitPane.setLeftComponent(textArea1);
		
		JTextArea textArea2 = new JTextArea();
		splitPane.setRightComponent(textArea2);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		
		//File 메뉴
		JMenu mnNewMenu1 = new JMenu("File");
		menuBar.add(mnNewMenu1);
		
		//New 버튼
		JMenuItem mntmNewMenuItem1 = new JMenuItem("New");
		mntmNewMenuItem1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea1.setText("");
				address=null;
				runAddress=null;
			}
		});
		mnNewMenu1.add(mntmNewMenuItem1);
		
		//Open 버튼
		JMenuItem mntmNewMenuItem2 = new JMenuItem("Open");
		mntmNewMenuItem2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser fs=new JFileChooser(new File("c:\\"));
				fs.setDialogTitle("Open a File");
				fs.setFileFilter(new FileTypeFilter(".txt", "Text File"));
				fs.setFileFilter(new FileTypeFilter(".java", "JAVA File"));
				int result=fs.showOpenDialog(null);
				if(result==JFileChooser.APPROVE_OPTION) {
					File file=fs.getSelectedFile();
					try 
					{
						BufferedReader br=new BufferedReader(new FileReader(file.getPath()));
						String line="";
						String s="";
						while((line=br.readLine())!=null) {
							s+=line+"\n";
						}
						textArea1.setText(s);
						if(br!=null)
							br.close();
						
						address=(file.getPath()+".java");
						runAddress=address.substring(0, address.length()-5);
					}
					catch(Exception e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
				}
			}
		});
		mnNewMenu1.add(mntmNewMenuItem2);
		
		//Save 버튼
		JMenuItem mntmNewMenuItem3 = new JMenuItem("Save");
		mntmNewMenuItem3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fs=new JFileChooser(new File("c:\\"));
				fs.setDialogTitle("Save a File");
				fs.setFileFilter(new FileTypeFilter(".java", "JAVA File"));
				int result=fs.showSaveDialog(null);
				if(result==JFileChooser.APPROVE_OPTION) {
					String content = textArea1.getText();
					File file=fs.getSelectedFile();
					try {
						FileWriter fw=new FileWriter(file.getPath()+".java");
						fw.write(content);
						fw.flush();
						fw.close();
						
						address=(file.getPath()+".java");
						runAddress=address.substring(0, address.length()-5);
					}
					catch(Exception e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
				}
				
			}
		});
		mnNewMenu1.add(mntmNewMenuItem3);
		
		//Exit 버튼
		JMenuItem mntmNewMenuItem4 = new JMenuItem("Exit");
		mntmNewMenuItem4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnNewMenu1.add(mntmNewMenuItem4);
		
		
		//Edit 메뉴
		JMenu mnNewMenu2 = new JMenu("Edit");
		menuBar.add(mnNewMenu2);
		
		//Copy 버튼
		JMenuItem mntmNewMenuItem5 = new JMenuItem("Copy");
		mntmNewMenuItem5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StringSelection data = new StringSelection(textArea1.getSelectedText());
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(data, data);
			}
		});
		mnNewMenu2.add(mntmNewMenuItem5);
		
		//Paste 버튼
		JMenuItem mntmNewMenuItem6 = new JMenuItem("Paste");
		mntmNewMenuItem6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				Transferable contents = clipboard.getContents(clipboard);
			         String pasteString = null;
				try {
					pasteString = (String)(contents.getTransferData(DataFlavor.stringFlavor));
				} catch (UnsupportedFlavorException | IOException e1) {
					e1.printStackTrace();
				}
			        textArea1.insert(pasteString, textArea1.getCaretPosition());
			}
		});
		mnNewMenu2.add(mntmNewMenuItem6);
		
		//Cut 버튼
		JMenuItem mntmNewMenuItem7 = new JMenuItem("Cut");
		mntmNewMenuItem7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StringSelection data = new StringSelection(textArea1.getSelectedText());
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(data, data);
				int start = textArea1.getSelectionStart();
				int end = textArea1.getSelectionEnd();
				textArea1.replaceRange("", start, end);
			}
		});
		mnNewMenu2.add(mntmNewMenuItem7);
		
		
		//Compile 메뉴
		JMenu mnNewMenu3 = new JMenu("Compile");
		menuBar.add(mnNewMenu3);
		
		//Compile 버튼
		JMenuItem mntmNewMenuItem8 = new JMenuItem("Compile");
		mntmNewMenuItem8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String compileCommand="javac"+" "+address;
				
				Cmd cmd=new Cmd();
					
				String command=cmd.inputCommand(compileCommand);			
				String result=cmd.execCommand(command);
				
			}
		});
		mnNewMenu3.add(mntmNewMenuItem8);
		
		//Run 버튼
		JMenuItem mntmNewMenuItem9 = new JMenuItem("Run");
		mntmNewMenuItem9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String runCommand="java"+" "+runAddress;
				
				
				Cmd cmd=new Cmd();
					
				String command=cmd.inputCommand(runCommand);			
				String result=cmd.execCommand(command);
				
				textArea2.setText(result);
			}
		});
		mnNewMenu3.add(mntmNewMenuItem9);
		
	
	}

}
