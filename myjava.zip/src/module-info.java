module myjava {
	requires java.desktop;
}